# Kamala Oli — Professional IT Portfolio

A responsive portfolio website for a Junior System Administrator / IT Support / Networking profile.

## Files

- `index.html` — website content
- `style.css` — complete responsive design
- `script.js` — mobile navigation, scroll progress and back-to-top button
- `resume/Kamala-Oli-Resume.pdf` — place your final resume PDF here

## Before publishing

Open `index.html` and replace:

1. `YOUR-GITHUB-USERNAME` with your GitHub username.
2. `YOUR-LINKEDIN-USERNAME` with your LinkedIn profile username.
3. Add your real resume as `resume/Kamala-Oli-Resume.pdf`.
4. Replace project GitHub links with the actual repository links.
5. Only keep certification labels that match certificates you actually hold; use "Training" for training programs.
6. Add real certificate verification links if available.

## GitHub Pages

1. Create a repository named `<your-username>.github.io`.
2. Upload `index.html`, `style.css`, `script.js`, the `resume` folder and any other assets.
3. Open repository Settings → Pages.
4. Under Build and deployment, select "Deploy from a branch".
5. Select the `main` branch and `/ (root)`.
6. Save and wait for the site to publish.

Your site will normally be:
`https://<your-username>.github.io/`

## Recommended GitHub project structure

Create separate repositories for substantial projects:

- `linux-server-monitoring`
- `ccna-enterprise-network-lab`
- `windows-server-active-directory-lab`
- `airline-ticket-management-system`

For each project, include a README with:
Objective → Technologies → Architecture → Configuration/Code → Screenshots → Testing → Result → Future improvements.
